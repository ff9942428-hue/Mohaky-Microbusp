package com.fares.microbus;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.JavascriptInterface;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView webView;
    private TextToSpeech tts;
    private boolean ttsReady = false;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setSystemUiVisibility(
            5894 | 1024 | 512 | 4096
        );
        webView = new WebView(this);
        webView.setBackgroundColor(0xFF10131C);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(false);
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new GameBridge(), "AndroidGame");
        setContentView(webView);
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int result = tts.setLanguage(new Locale("ar"));
                ttsReady = result != TextToSpeech.LANG_MISSING_DATA &&
                           result != TextToSpeech.LANG_NOT_SUPPORTED;
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class GameBridge {
        @JavascriptInterface public void speak(String message) {
            runOnUiThread(() -> {
                if (tts != null && ttsReady && message != null) {
                    tts.setSpeechRate(0.88f);
                    tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "microbus_voice");
                }
            });
        }
        @JavascriptInterface public boolean voiceAvailable() { return ttsReady; }
    }

    @Override protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        if (webView != null) { webView.destroy(); }
        super.onDestroy();
    }
}
